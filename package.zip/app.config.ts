export default defineAppConfig({
    ui: {
      primary: 'sky',
      gray: 'slate'
    }
  })
  